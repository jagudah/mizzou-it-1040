from turtle import Turtle

def makeSquares(turtle, l):
    for x in range(4):
        turtle.forward(l)
        turtle.left(90)

        turtle.forward(l)
        turtle.left(90)

        turtle.forward(l)
        turtle.left(90)

        turtle.forward(l)
        turtle.left(90)

        turtle.forward(50)

def main():

    t1 = Turtle()
    length = 100
    makeSquares(t1, length)

main()