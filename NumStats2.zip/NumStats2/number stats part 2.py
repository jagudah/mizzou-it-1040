#numberstats part 2
filename2="numbers.txt"
def stats(filename):
    try:
        f=open(file_name,'r')

        nums= f.readlines()
        nums=[int(i)for i in nums]
        count = len(nums)
        nums.sort()

        if count % 2 != 0:
            index_Num = int(count // 2)
            median = nums[index_Num]
        else:
            lower_Median = int((count // 2) - 1)
            upper_Median = int((count // 2))
            median = float((nums[lower_Median] + nums[upper_Median]) / 2)

        nums_Dict = {}
        mode = []
        initial_Mode = 0
        for x in nums:
            if x in nums_Dict:
                nums_Dict[x] += 1
            else:
                nums_Dict[x] = 1
            for x in nums_Dict:
                if nums_Dict[x] == initial_Mode:
                    mode.append(int(x))
                if nums_Dict[x] > initial_Mode:
                    initial_Mode = nums_Dict[x]
                    mode.clear()
                    mode.append(int(x))
                    
        f.close()

        print( "File name:, ",file_name)
        print ("sum:", sum(nums))
        print("count:", count)
        print("average:", (sum(nums)/len(nums)))
        print("maximums:", max(nums))
        print("minimums:",min(nums))
        print("median:",median)
        print("mode:", str(mode))
    except:
        print("an exception occured: enter a file name")
while True:     
    file_name = input("enter file name:")
    stats(filename2)
    response = input("would like another? ")
    if(response) =="n":
        break

# find mode
#find median

"""number_list.sort()
count=len(number_list)
number_counts={}
for number in number_list:
    if number in number_counts:
        number_counts[number]+=1
        number_counts[number]=1
for number in number_counts:
    count=number_counts[number]
for number in number_list:
    count=number_count[number]"""
    
