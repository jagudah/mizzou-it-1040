import Document, os 

print("Welcome to the Document Generation Program!")

titleList = []
bodyList = []
authorList = []

do_Generation = True
while(do_Generation):
    try:
        title = input("Enter title: ")
        body = input("Enter body: ")
        author = input("Enter author: ")

        myDocument = Document.Document(title, body, author)
        
        title1 = myDocument.get_title()
        titleList.append(title1)

        body1 = myDocument.get_body()
        bodyList.append(body1)

        author1 = myDocument.get_author()
        authorList.append(author1)

        choice = input("Would you like to generate another Document? (y/n)")
        if(choice != 'y'):
            do_Generation = False
        
            count = 0
            while(count < len(authorList)):
                print("Title: %s, Body: %s, Author: %s" %(titleList[count], bodyList[count], authorList[count]))
                count += 1

    except Exception as err:
        print(err)