
class Document(object):

    def __init__(self, title, body, author):
        self.__title = title
        self.__body = body
        self.__author = author

    def get_title(self):
        return self.__title

    def get_body(self):
        return self.__body

    def get_author(self):
        return self.__author