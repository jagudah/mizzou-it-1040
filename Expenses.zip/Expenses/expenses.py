import io, os, csv

creditCard = {
    "totalCost": 0,
    "totalPurchases": 0,
    "diningCosts": 0,
    "merchCosts": 0,
    "healthCosts": 0,
    "otherCosts": 0,
    "diningNum": 0,
    "merchNum": 0,
    "healthNum": 0,
    "otherNum": 0,
    "highestCategory": [],
    "lowestCategory": [],
    "averageCost": 0
}

fname = input("Please enter csv file name (w/o extension): ")
f = open(fname + ".csv", "r")
do_Scan = True

while(do_Scan):
    while True:
        try:
            line = f.readline()
            if(len(line) == 0):
                break
            purchase = line.partition(',')

            if(purchase[0] == "Merchandise"):
                creditCard["totalCost"] += float(purchase[2])
                creditCard["totalPurchases"] += 1
                creditCard["merchCosts"] += float(purchase[2])
                creditCard["merchNum"] += 1

            elif(purchase[0] == "Dining"):
                creditCard["totalCost"] += float(purchase[2])
                creditCard["totalPurchases"] += 1
                creditCard["diningCosts"] += float(purchase[2])
                creditCard["diningNum"] += 1

            elif(purchase[0] == "Health Care"):
                creditCard["totalCost"] += float(purchase[2])
                creditCard["totalPurchases"] += 1
                creditCard["healthCosts"] += float(purchase[2])
                creditCard["healthNum"] += 1

            elif("Other" in purchase[0]):
                creditCard["totalCost"] += float(purchase[2])
                creditCard["totalPurchases"] += 1
                creditCard["otherCosts"] += float(purchase[2])
                creditCard["otherNum"] += 1
            
            if(len(creditCard["highestCategory"]) == 0 or float(purchase[2]) > creditCard["highestPurchase"]):
                creditCard["highestCategory"].clear()
                creditCard["highestCategory"].append(purchase[0])
                creditCard.update({"highestPurchase": float(purchase[2])})

            elif(float(purchase[2]) == creditCard["highestPurchase"]):
                creditCard["highestCategory"].append(purchase[0])
                
            if(len(creditCard["lowestCategory"]) == 0 or float(purchase[2]) < creditCard["lowestPurchase"]):
                creditCard["lowestCategory"].clear()
                creditCard["lowestCategory"].append(purchase[0])
                creditCard.update({"lowestPurchase": float(purchase[2])})

            elif(float(purchase[2]) == creditCard["lowestPurchase"]):
                creditCard["lowestCategory"].append(purchase[0])

            avg = (creditCard["totalCost"] / creditCard["totalPurchases"])
            creditCard["averageCost"] = avg

        except Exception as err:
            print(err)

    print("Total cost of purchases: $%.2f" %creditCard["totalCost"])
    print("Number of purchases: %d" %creditCard["totalPurchases"])
    print("Total merchandise costs: $%.2f" %creditCard["merchCosts"])
    print("Total dining costs: $%.2f" %creditCard["diningCosts"])
    print("Total health costs: $%.2f" %creditCard["healthCosts"])
    print("Total other costs: $%.2f" %creditCard["otherCosts"])
    print("Total merchandise purchases: %d" %creditCard["merchNum"])
    print("Total dining purchases: %d" %creditCard["diningNum"])
    print("Total health purchases: %d" %creditCard["healthNum"])
    print("Total other purchases: %d" %creditCard["otherNum"])
    print("Most expensive purchase: %s - $%.2f" %(creditCard["highestCategory"], creditCard["highestPurchase"]))
    print("Least expensive purchase: %s - $%.2f" %(creditCard["lowestCategory"], creditCard["lowestPurchase"]))
    print("Average purchase cost: $%.2f" %creditCard["averageCost"])
    f.close()

    choice = input("Would you like to do another scan (y/n)? ")
    if choice != "y":
        do_Scan = False
    else:
        fname = input("\nPlease enter csv file name (w/o extension): ")
        f = open(fname + ".csv", "r")