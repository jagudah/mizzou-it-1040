import io, os, csv

crypto = {
    'filename': '',
    'name': '',
    'symbol': '',
    'maxClosePrice': 0,
    'maxCloseDates': [],
    'minClosePrice': 0,
    'minCloseDates': [],
    'maxMarketCap': 0,
    'maxCapDates': [],
    'totalOpenPrice': 0,
    'avgOpenPrice': 0,
    'totalClosePrice': 0,
    'avgClosePrice': 0,
    'entriesNum': 0
}

do_Scan = True

while(do_Scan):
    while True:
        try:
            fname = input("\nPlease enter csv file name (w/o extension): ")
            f = open(fname + '.csv', 'r')
            lines = f.readlines()
            crypto['entriesNum'] = len(lines) - 1
            for x in lines:
                if(x[0].isdigit()):
                    stock = x.split(',')
                    date = stock[3].split(' ')

                    crypto['filename'] = fname + '.csv'
                    crypto['name'] = stock[1]
                    crypto['symbol'] = stock[2]
                    crypto['totalOpenPrice'] += float(stock[6])
                    crypto['totalClosePrice'] += float(stock[7])

                    if(len(crypto["maxCloseDates"]) == 0 or float(stock[7]) > crypto["maxClosePrice"]):
                        crypto["maxCloseDates"].clear()
                        crypto["maxCloseDates"].append(date[0])
                        crypto.update({"maxClosePrice": float(stock[7])})
                
                    elif(float(stock[7]) == crypto["maxClosePrice"]):
                        crypto["maxCloseDates"].append(date[0])
                        
                    if(len(crypto["minCloseDates"]) == 0 or float(stock[7]) < crypto["minClosePrice"]):
                        crypto["minCloseDates"].clear()
                        crypto["minCloseDates"].append(date[0])
                        crypto.update({"minClosePrice": float(stock[7])})

                    elif(float(stock[7]) == crypto["minClosePrice"]):
                        crypto["minCloseDates"].append(date[0])

                    if(len(crypto["maxCapDates"]) == 0 or float(stock[9]) > crypto["maxMarketCap"]):
                        crypto["maxCapDates"].clear()
                        crypto["maxCapDates"].append(date[0])
                        crypto.update({"maxMarketCap": float(stock[9])})

                    elif(float(stock[7]) == crypto["maxMarketCap"]):
                        crypto["maxCapDates"].append(date[0])

                    openAvg = (crypto['totalOpenPrice'] / crypto['entriesNum'])
                    closeAvg = (crypto['totalClosePrice'] / crypto['entriesNum'])
                    crypto['avgOpenPrice'] = openAvg
                    crypto['avgClosePrice'] = closeAvg

                elif(len(x) == 0):
                    break
    
            print("File name: %s" %crypto["filename"])
            print("Crypto currency symbol: %s" %crypto["symbol"])
            print("Crypto currency name: %s" %crypto["name"])
            print("Highest closing price: $%4.2f on %s" %(float(crypto["maxClosePrice"]), crypto["maxCloseDates"]))
            print("Lowest closing price: $%4.2f on %s" %(float(crypto["minClosePrice"]), crypto["minCloseDates"]))
            print("Highest market cap: $%4.2f on %s" %(float(crypto["maxMarketCap"]), crypto["maxCapDates"]))
            print("Average opening price: $%4.2f" %(float(crypto["avgOpenPrice"])))
            print("Average closing price: $%4.2f" %(float(crypto["avgClosePrice"])))
            print("Number of entries: %d" %crypto['entriesNum'])
            f.close()
            break

        except FileNotFoundError:
            print("ERROR: File could NOT be found!\n")
            break

        except Exception as err:
            print(err)
            break

    choice = input("Would you like to evaluate another file? (y/n)")
    if(choice != 'y'):
        do_Scan = False
        print("Thank you for using the Crypto Statistics Program :)")